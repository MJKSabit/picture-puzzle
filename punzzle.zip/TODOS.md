# Tasks to do next

This is a list of tasks left to implement. This list will be updated on the go.

* if password recovery is not allowed ... email field is not required -> decide what to do

* **Contest arena**
    * add pop up messages for login, logout, and register 
        * welcome 
        * goodbye
        * pass from backend

* clean .env file -> remove unnecessary variables
* clean unnecessary files
* probably Footer-Dark.css file is not needed and can be deleted
    
* **shomobay shomiti**
    * testing
    * learning parameters
    * model
    * try cutting down updates by half => participant1_id < participant2_id
    * leader board
    
## Updates in last version
* form validation messages
* leaderboard pagination